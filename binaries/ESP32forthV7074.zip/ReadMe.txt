You will found here 3 files:

 - ESP32forthV7074.ino  --> CASE bug fixed in this version
 - ESP32forthV7074.ino.bin
 - ESP32forthV7074.ino.partitions.bin


File ESP32forthV7074.ino

This file is to be compiled and transferred to the ESP32 board using ARDUINO IDE.
Learn more:
https://esp32.arduino-forth.com/article/installation_instalESP32forth


Files ESP32forthV7074.ino.bin & ESP32forthV7074.ino.partitions.bin

These files can be transferred directly to the ESP32 board without having to go through ARDUINO IDE.
Learn more:
https://esp32.arduino-forth.com/article/installation_instalFromBinaries

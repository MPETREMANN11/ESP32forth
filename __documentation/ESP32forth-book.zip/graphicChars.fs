\ *********************************************************************
\ Compile graphics characters
\    Filename:      graphicChars.fs
\    Date:          17 aug 2022
\    Updated:       17 aug 2022
\    File Version:  1.0
\    MCU:           ESP32-WROOM-32
\    Forth:         ESP32forth versions 7.0.6++
\    Copyright:     Marc PETREMANN
\    Author:        Marc PETREMANN
\    GNU General Public License
\ *********************************************************************

\ Work only with PuTTy terminal

internals
: graphic: 
    create ( c1 c2 c3 -- )
        c, c, c,
    does>
        3 serial-type
  ;
forth

\ to find UTF8 code for a graphic caracter:
\ link: https://www.w3.org/TR/xml-entity-names/025.html
\ Example: ▓
\ copy ▓ and go in PuTTy terminal, and type:
\   key key key    <enter>
\ paste: ▓
\ ESP32forth display stack: 
\   226 150 147 -->

147 150 226 graphic: ▓



\ use:
▓ \  <enter>
\ display ▓
